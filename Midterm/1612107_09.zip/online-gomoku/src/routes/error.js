import React from 'react'

export const Error = () => (
    <div>
        <h1>Something wrong happened!!!</h1>
    </div>
)
